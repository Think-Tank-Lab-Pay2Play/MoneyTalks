const express = require("express");
const multer = require("multer");
const cors = require("cors");
const admin = require("firebase-admin");
const uuid = require("uuid").v4;
const fs = require('fs');
const path = require('path');
const { exec } = require("child_process");

const serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  storageBucket: "moneytalks-da829.firebasestorage.app"
});

const bucket = admin.storage().bucket();

const server = express();
server.use(cors());
server.use(express.json());

const upload = multer({ storage: multer.memoryStorage() });

// Ruta GET pentru upload
server.get("/upload", (req, res) => {
  res.send(`
    <html>
      <head>
        <title>Upload Imagine</title>
      </head>
      <body>
        <h1>Încarcă o imagine</h1>
        <form method="POST" action="/upload" enctype="multipart/form-data">
          <input type="file" name="image" accept="image/*" />
          <button type="submit">Încarcă</button>
        </form>
      </body>
    </html>
  `);
});


server.post('/generateUserIdFile', (req, res) => {
  const { userId, numberOfPictures } = req.body;

  if (!userId) {
    return res.status(400).json({ message: 'User ID nu a fost furnizat' });
  }

  const userData = { userId, numberOfPictures };
  /*

  const filePath = path.join("../src/pages/uploadBill/uploadBillForm", 'myUserId.json'); // Salvează fișierul în același director

  // Scrie fișierul JSON pe server
  fs.writeFile(filePath, JSON.stringify(userData, null, 2), (err) => {
    if (err) {
      return res.status(500).json({ message: 'Eroare la salvarea fișierului', error: err });
    }
    //res.status(200).json({ message: 'Fișierul a fost generat cu succes!', filePath });
    res.status(200);
  });
  */


  const filePath2 = path.join(__dirname, 'myUserId.json'); // Salvează fișierul în același director

  // Scrie fișierul JSON pe server
  fs.writeFile(filePath2, JSON.stringify(userData, null, 2), (err) => {
    if (err) {
      return res.status(500).json({ message: 'Eroare la salvarea fișierului', error: err });
    }

    //res.status(200).json({ message: 'Fișierul a fost generat cu succes!', filePath });
    res.status(200);
  });

});



server.post("/upload/", upload.single("image"), async (req, res) => {
  if (!req.file) return res.status(400).send("No file uploaded");

  const filePath = path.join(__dirname, "myUserId.json");

  try {
    const fileData = fs.readFileSync(filePath, "utf8");
    const parsedData = JSON.parse(fileData);
    const userId = parsedData.userId;

    const userFolder = `upload/${userId}/`;

    const [files] = await bucket.getFiles({ prefix: userFolder });

    const numberOfPictures = files.length + 1;

    const filename = `${userFolder}${numberOfPictures}.png`;
    const file = bucket.file(filename);

    await file.save(req.file.buffer, { resumable: false });
    await file.makePublic();

    const downloadURL = `https://storage.googleapis.com/${bucket.name}/${filename}`;

    res.json({ imageUrl: downloadURL });
  } catch (error) {
    console.error("Error uploading file:", error);
    res.status(500).send("Upload failed");
  }
});


server.listen(3001, () => console.log("Server running on http://localhost:3001"));
